#!/data/home/John.Wambaugh/.local/bin/ Rapp
#| name: httkqsprs
#| description: A cool CLI tool built with Rapp

# Top-level assignments automatically become CLI flags
label <- "NewHTTK_April_2026" # becomes --input-file
output.dir <- "." 

cat(getwd(),"\n")

library(httkqsprs)
message("Processing OPERA and Padel descriptor files starting with text: ", label)

generate_preds(label, output.dir)
