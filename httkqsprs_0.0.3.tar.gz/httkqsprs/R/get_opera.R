#' Retrieve OPeRA descriptors from SQL database
#' 
#' @author John Wambaugh and Andy Shapiro
#'
#' @references
#' Mansouri, Kamel, et al. "OPERA models for predicting physicochemical properties and environmental fate endpoints." Journal of cheminformatics 10.1 (2018): 10.
#' 
#' @export get_opera
get_opera <- function(cichem_list = chems,
                      descriptors = NULL,
                      opera_version = "2.9", 
                      conn_str = NULL)
{
  if (is.null(conn_str)) {
    if (is.null(PIPELINES_CONN_STR)) conn_str <- Sys.getenv("PIPELINES_CONN_STR")
    else conn_str <- PIPELINES_CONN_STR
  } 
  # Code from Andy Shapiro:
  if (nchar(conn_str) == 0) stop("PIPELINES_CONN_STR is not set")

  uri   <- httr::parse_url(conn_str)  # parse URI components without httr if preferred
  # Pure-base alternative using regex:
  m <- regmatches(conn_str, regexpr(
    "postgres://([^:]+):([^@]+)@([^:/]+)(?::(\\d+))?/(.+)", conn_str, perl = TRUE
  ))
  parts <- regmatches(conn_str, regexec(
    "postgres://([^:]+):([^@]+)@([^:/]+)(?::(\\d+))?/(.+)", conn_str, perl = TRUE
  ))[[1]]

  con <- dbConnect(
    RPostgres::Postgres(),
    user     = parts[2],
    password = parts[3],
    host     = parts[4],
    port     = if (nchar(parts[5]) > 0) as.integer(parts[5]) else 5432L,
    dbname   = parts[6]
  )
  on.exit(dbDisconnect(con), add = TRUE)

  # ── Parameters ────────────────────────────────────────────────────────────────
  # parameters are set by call to function
  column_names  <- descriptors # NULL = all descriptors; or e.g. c("ALogP", "AMR")

# Convert names as given by OPERA Excel output into SQL names:
Opera.SQL.names <- paste0("opera_",
  gsub("_pred","",tolower(Descriptors$Opera)),
  "_endpoint") 
Opera.SQL.names <- gsub("logws","ws", Opera.SQL.names)
Opera.SQL.names <- gsub("logbcf","bcf", Opera.SQL.names)
Opera.SQL.names <- gsub("logkm","km", Opera.SQL.names)
Opera.SQL.names <- gsub("logoh","aoh", Opera.SQL.names)
Opera.SQL.suffix <- rep("prediction",length(Opera.SQL.names))
Opera.SQL.suffix[Opera.SQL.names=="logd55"] <- "logd55"
Opera.SQL.suffix[Opera.SQL.names=="logd74"] <- "logd74"
Opera.SQL.names <- gsub("logd55","", Opera.SQL.names)
Opera.SQL.names <- gsub("logd74","", Opera.SQL.names)



  # ── Build column annotation for RETURNS SETOF RECORD ─────────────────────────
  # The function returns an untyped record set, so we must tell PostgreSQL the
  # column names and types in the calling AS t(...) clause.

  lookup_sql <- "
    SELECT name
    FROM   descriptor_lookup
    WHERE  tool_name    = 'Padel'
      AND  tool_version = $1
      AND  ($2::TEXT[] IS NULL OR name = ANY($2::TEXT[]))
    ORDER  BY index
  "
  descriptor_names <- dbGetQuery(con, lookup_sql, params = list(
      opera_version,
      ifelse(is.null(column_names), 
        NA, 
        paste0("{", paste(column_names, collapse = ","), "}")
        )  # NA -> NULL in RPostgres
      )
    )$name

  col_defs <- paste(
    c('"cichem" TEXT',
      paste0('"', descriptor_names, '" FLOAT8')),
    collapse = ", "
  )

  opera_query <- paste0('
SELECT "chemical_identifier"."cichem",
       "opera_prediction_molecule"."inchikey",
       "opera_prediction_molecule"."opera_version",
       "opera_prediction_molecule"."row_id",
       "opera_prediction_molecule"."original_smiles",
       "opera_prediction_molecule"."num_connected_components",
       "opera_prediction_molecule"."canonical_qsarr",
       "opera_prediction_molecule"."inchi_code_qsarr",
       "opera_prediction_molecule"."inchi_key_qsarr",
       "opera_prediction_molecule"."salt_solvent",
       "opera_prediction_molecule"."salt_solvent_id",
       "opera_prediction_molecule"."is_qsar_ready",
       "opera_prediction_molecule"."discard_error",
       "opera_prediction_molecule"."created_on",
       "opera_prediction_molecule"."updated_on",
       "opera_aoh_endpoint"."id",
       "opera_aoh_endpoint"."prediction",
       "opera_aoh_endpoint"."prediction_range",
       "opera_aoh_endpoint"."prediction_lower",
       "opera_aoh_endpoint"."prediction_upper",
       "opera_aoh_endpoint"."ad_flag",
       "opera_aoh_endpoint"."ad_index",
       "opera_aoh_endpoint"."conf_index",
       "opera_aoh_endpoint"."cas_neighbors",
       "opera_aoh_endpoint"."inchi_key_neighbors",
       "opera_aoh_endpoint"."dtxsid_neighbors",
       "opera_aoh_endpoint"."exp_neighbors",
       "opera_aoh_endpoint"."pred_neighbors",
       "opera_aoh_endpoint"."molecule_id",
       "opera_bcf_endpoint"."id",
       "opera_bcf_endpoint"."prediction",
       "opera_bcf_endpoint"."prediction_range",
       "opera_bcf_endpoint"."prediction_lower",
       "opera_bcf_endpoint"."prediction_upper",
       "opera_bcf_endpoint"."ad_flag",
       "opera_bcf_endpoint"."ad_index",
       "opera_bcf_endpoint"."conf_index",
       "opera_bcf_endpoint"."cas_neighbors",
       "opera_bcf_endpoint"."inchi_key_neighbors",
       "opera_bcf_endpoint"."dtxsid_neighbors",
       "opera_bcf_endpoint"."exp_neighbors",
       "opera_bcf_endpoint"."pred_neighbors",
       "opera_bcf_endpoint"."molecule_id",
       "opera_biodeg_endpoint"."id",
       "opera_biodeg_endpoint"."prediction",
       "opera_biodeg_endpoint"."prediction_range",
       "opera_biodeg_endpoint"."prediction_lower",
       "opera_biodeg_endpoint"."prediction_upper",
       "opera_biodeg_endpoint"."ad_flag",
       "opera_biodeg_endpoint"."ad_index",
       "opera_biodeg_endpoint"."conf_index",
       "opera_biodeg_endpoint"."cas_neighbors",
       "opera_biodeg_endpoint"."inchi_key_neighbors",
       "opera_biodeg_endpoint"."dtxsid_neighbors",
       "opera_biodeg_endpoint"."exp_neighbors",
       "opera_biodeg_endpoint"."pred_neighbors",
       "opera_biodeg_endpoint"."molecule_id",
       "opera_bp_endpoint"."id",
       "opera_bp_endpoint"."prediction",
       "opera_bp_endpoint"."prediction_range",
       "opera_bp_endpoint"."prediction_lower",
       "opera_bp_endpoint"."prediction_upper",
       "opera_bp_endpoint"."ad_flag",
       "opera_bp_endpoint"."ad_index",
       "opera_bp_endpoint"."conf_index",
       "opera_bp_endpoint"."cas_neighbors",
       "opera_bp_endpoint"."inchi_key_neighbors",
       "opera_bp_endpoint"."dtxsid_neighbors",
       "opera_bp_endpoint"."exp_neighbors",
       "opera_bp_endpoint"."pred_neighbors",
       "opera_bp_endpoint"."molecule_id",
       "opera_caco2_endpoint"."id",
       "opera_caco2_endpoint"."prediction",
       "opera_caco2_endpoint"."prediction_range",
       "opera_caco2_endpoint"."prediction_lower",
       "opera_caco2_endpoint"."prediction_upper",
       "opera_caco2_endpoint"."ad_flag",
       "opera_caco2_endpoint"."ad_index",
       "opera_caco2_endpoint"."conf_index",
       "opera_caco2_endpoint"."cas_neighbors",
       "opera_caco2_endpoint"."inchi_key_neighbors",
       "opera_caco2_endpoint"."dtxsid_neighbors",
       "opera_caco2_endpoint"."exp_neighbors",
       "opera_caco2_endpoint"."pred_neighbors",
       "opera_caco2_endpoint"."molecule_id",
       "opera_clint_endpoint"."id",
       "opera_clint_endpoint"."prediction",
       "opera_clint_endpoint"."prediction_range",
       "opera_clint_endpoint"."prediction_lower",
       "opera_clint_endpoint"."prediction_upper",
       "opera_clint_endpoint"."ad_flag",
       "opera_clint_endpoint"."ad_index",
       "opera_clint_endpoint"."conf_index",
       "opera_clint_endpoint"."cas_neighbors",
       "opera_clint_endpoint"."inchi_key_neighbors",
       "opera_clint_endpoint"."dtxsid_neighbors",
       "opera_clint_endpoint"."exp_neighbors",
       "opera_clint_endpoint"."pred_neighbors",
       "opera_clint_endpoint"."molecule_id",
       "opera_fub_endpoint"."id",
       "opera_fub_endpoint"."prediction",
       "opera_fub_endpoint"."prediction_range",
       "opera_fub_endpoint"."prediction_lower",
       "opera_fub_endpoint"."prediction_upper",
       "opera_fub_endpoint"."ad_flag",
       "opera_fub_endpoint"."ad_index",
       "opera_fub_endpoint"."conf_index",
       "opera_fub_endpoint"."cas_neighbors",
       "opera_fub_endpoint"."inchi_key_neighbors",
       "opera_fub_endpoint"."dtxsid_neighbors",
       "opera_fub_endpoint"."exp_neighbors",
       "opera_fub_endpoint"."pred_neighbors",
       "opera_fub_endpoint"."molecule_id",
       "opera_hl_endpoint"."id",
       "opera_hl_endpoint"."prediction",
       "opera_hl_endpoint"."prediction_range",
       "opera_hl_endpoint"."prediction_lower",
       "opera_hl_endpoint"."prediction_upper",
       "opera_hl_endpoint"."ad_flag",
       "opera_hl_endpoint"."ad_index",
       "opera_hl_endpoint"."conf_index",
       "opera_hl_endpoint"."cas_neighbors",
       "opera_hl_endpoint"."inchi_key_neighbors",
       "opera_hl_endpoint"."dtxsid_neighbors",
       "opera_hl_endpoint"."exp_neighbors",
       "opera_hl_endpoint"."pred_neighbors",
       "opera_hl_endpoint"."molecule_id",
       "opera_km_endpoint"."id",
       "opera_km_endpoint"."prediction",
       "opera_km_endpoint"."prediction_range",
       "opera_km_endpoint"."prediction_lower",
       "opera_km_endpoint"."prediction_upper",
       "opera_km_endpoint"."ad_flag",
       "opera_km_endpoint"."ad_index",
       "opera_km_endpoint"."conf_index",
       "opera_km_endpoint"."cas_neighbors",
       "opera_km_endpoint"."inchi_key_neighbors",
       "opera_km_endpoint"."dtxsid_neighbors",
       "opera_km_endpoint"."exp_neighbors",
       "opera_km_endpoint"."pred_neighbors",
       "opera_km_endpoint"."molecule_id",
       "opera_koa_endpoint"."id",
       "opera_koa_endpoint"."prediction",
       "opera_koa_endpoint"."prediction_range",
       "opera_koa_endpoint"."prediction_lower",
       "opera_koa_endpoint"."prediction_upper",
       "opera_koa_endpoint"."ad_flag",
       "opera_koa_endpoint"."ad_index",
       "opera_koa_endpoint"."conf_index",
       "opera_koa_endpoint"."cas_neighbors",
       "opera_koa_endpoint"."inchi_key_neighbors",
       "opera_koa_endpoint"."dtxsid_neighbors",
       "opera_koa_endpoint"."exp_neighbors",
       "opera_koa_endpoint"."pred_neighbors",
       "opera_koa_endpoint"."molecule_id",
       "opera_koc_endpoint"."id",
       "opera_koc_endpoint"."prediction",
       "opera_koc_endpoint"."prediction_range",
       "opera_koc_endpoint"."prediction_lower",
       "opera_koc_endpoint"."prediction_upper",
       "opera_koc_endpoint"."ad_flag",
       "opera_koc_endpoint"."ad_index",
       "opera_koc_endpoint"."conf_index",
       "opera_koc_endpoint"."cas_neighbors",
       "opera_koc_endpoint"."inchi_key_neighbors",
       "opera_koc_endpoint"."dtxsid_neighbors",
       "opera_koc_endpoint"."exp_neighbors",
       "opera_koc_endpoint"."pred_neighbors",
       "opera_koc_endpoint"."molecule_id",
       "opera_logp_endpoint"."id",
       "opera_logp_endpoint"."prediction",
       "opera_logp_endpoint"."prediction_range",
       "opera_logp_endpoint"."prediction_lower",
       "opera_logp_endpoint"."prediction_upper",
       "opera_logp_endpoint"."ad_flag",
       "opera_logp_endpoint"."ad_index",
       "opera_logp_endpoint"."conf_index",
       "opera_logp_endpoint"."cas_neighbors",
       "opera_logp_endpoint"."inchi_key_neighbors",
       "opera_logp_endpoint"."dtxsid_neighbors",
       "opera_logp_endpoint"."exp_neighbors",
       "opera_logp_endpoint"."pred_neighbors",
       "opera_logp_endpoint"."molecule_id",
       "opera_mp_endpoint"."id",
       "opera_mp_endpoint"."prediction",
       "opera_mp_endpoint"."prediction_range",
       "opera_mp_endpoint"."prediction_lower",
       "opera_mp_endpoint"."prediction_upper",
       "opera_mp_endpoint"."ad_flag",
       "opera_mp_endpoint"."ad_index",
       "opera_mp_endpoint"."conf_index",
       "opera_mp_endpoint"."cas_neighbors",
       "opera_mp_endpoint"."inchi_key_neighbors",
       "opera_mp_endpoint"."dtxsid_neighbors",
       "opera_mp_endpoint"."exp_neighbors",
       "opera_mp_endpoint"."pred_neighbors",
       "opera_mp_endpoint"."molecule_id",
       "opera_vp_endpoint"."id",
       "opera_vp_endpoint"."prediction",
       "opera_vp_endpoint"."prediction_range",
       "opera_vp_endpoint"."prediction_lower",
       "opera_vp_endpoint"."prediction_upper",
       "opera_vp_endpoint"."ad_flag",
       "opera_vp_endpoint"."ad_index",
       "opera_vp_endpoint"."conf_index",
       "opera_vp_endpoint"."cas_neighbors",
       "opera_vp_endpoint"."inchi_key_neighbors",
       "opera_vp_endpoint"."dtxsid_neighbors",
       "opera_vp_endpoint"."exp_neighbors",
       "opera_vp_endpoint"."pred_neighbors",
       "opera_vp_endpoint"."molecule_id",
       "opera_ws_endpoint"."id",
       "opera_ws_endpoint"."prediction",
       "opera_ws_endpoint"."prediction_range",
       "opera_ws_endpoint"."prediction_lower",
       "opera_ws_endpoint"."prediction_upper",
       "opera_ws_endpoint"."ad_flag",
       "opera_ws_endpoint"."ad_index",
       "opera_ws_endpoint"."conf_index",
       "opera_ws_endpoint"."cas_neighbors",
       "opera_ws_endpoint"."inchi_key_neighbors",
       "opera_ws_endpoint"."dtxsid_neighbors",
       "opera_ws_endpoint"."exp_neighbors",
       "opera_ws_endpoint"."pred_neighbors",
       "opera_ws_endpoint"."molecule_id",
       "opera_rbiodeg_endpoint"."id",
       "opera_rbiodeg_endpoint"."molecule_id",
       "opera_rbiodeg_endpoint"."prediction",
       "opera_rbiodeg_endpoint"."ad_flag",
       "opera_rbiodeg_endpoint"."ad_index",
       "opera_rbiodeg_endpoint"."conf_index",
       "opera_rbiodeg_endpoint"."cas_neighbors",
       "opera_rbiodeg_endpoint"."inchi_key_neighbors",
       "opera_rbiodeg_endpoint"."dtxsid_neighbors",
       "opera_rbiodeg_endpoint"."exp_neighbors",
       "opera_rbiodeg_endpoint"."pred_neighbors",
       "opera_rt_endpoint"."id",
       "opera_rt_endpoint"."molecule_id",
       "opera_rt_endpoint"."prediction",
       "opera_rt_endpoint"."prediction_range",
       "opera_rt_endpoint"."prediction_lower",
       "opera_rt_endpoint"."prediction_upper",
       "opera_rt_endpoint"."ad_flag",
       "opera_rt_endpoint"."ad_index",
       "opera_rt_endpoint"."conf_index",
       "opera_rt_endpoint"."cas_neighbors",
       "opera_rt_endpoint"."dtxsid_neighbors",
       "opera_rt_endpoint"."exp_neighbors",
       "opera_rt_endpoint"."pred_neighbors",
       "opera_logd_endpoint"."id",
       "opera_logd_endpoint"."molecule_id",
       "opera_logd_endpoint"."logd55",
       "opera_logd_endpoint"."logd55_range",
       "opera_logd_endpoint"."logd55_lower",
       "opera_logd_endpoint"."logd55_upper",
       "opera_logd_endpoint"."logd74",
       "opera_logd_endpoint"."logd74_range",
       "opera_logd_endpoint"."logd74_lower",
       "opera_logd_endpoint"."logd74_upper",
       "opera_logd_endpoint"."ad_flag",
       "opera_logd_endpoint"."ad_index",
       "opera_logd_endpoint"."conf_index",
       "opera_logd_endpoint"."cas_neighbors",
       "opera_logd_endpoint"."inchi_key_neighbors",
       "opera_logd_endpoint"."dtxsid_neighbors",
       "opera_pka_endpoint"."id",
       "opera_pka_endpoint"."molecule_id",
       "opera_pka_endpoint"."ionization",
       "opera_pka_endpoint"."pka_a",
       "opera_pka_endpoint"."pka_a_range",
       "opera_pka_endpoint"."pka_a_lower",
       "opera_pka_endpoint"."pka_a_upper",
       "opera_pka_endpoint"."pka_b",
       "opera_pka_endpoint"."pka_b_range",
       "opera_pka_endpoint"."pka_b_lower",
       "opera_pka_endpoint"."pka_b_upper",
       "opera_pka_endpoint"."ad_flag",
       "opera_pka_endpoint"."ad_index",
       "opera_pka_endpoint"."conf_index",
       "opera_pka_endpoint"."cas_neighbors",
       "opera_pka_endpoint"."inchi_key_neighbors",
       "opera_pka_endpoint"."dtxsid_neighbors",
       "opera_pka_endpoint"."exp_neighbors",
       "opera_pka_endpoint"."pred_neighbors",
       "opera_catmos_endpoint"."id",
       "opera_catmos_endpoint"."molecule_id",
       "opera_catmos_endpoint"."vt_pred",
       "opera_catmos_endpoint"."nt_pred",
       "opera_catmos_endpoint"."epa_pred",
       "opera_catmos_endpoint"."ghs_pred",
       "opera_catmos_endpoint"."ld50_pred",
       "opera_catmos_endpoint"."ld50_range",
       "opera_catmos_endpoint"."ld50_lower",
       "opera_catmos_endpoint"."ld50_upper",
       "opera_catmos_endpoint"."ad_flag",
       "opera_catmos_endpoint"."ad_index",
       "opera_catmos_endpoint"."conf_index",
       "opera_catmos_endpoint"."cas_neighbors",
       "opera_catmos_endpoint"."inchi_key_neighbors",
       "opera_catmos_endpoint"."dtxsid_neighbors",
       "opera_catmos_endpoint"."exp_neighbors",
       "opera_catmos_endpoint"."pred_neighbors"
  FROM "opera_prediction_molecule"
  LEFT OUTER JOIN "chemical_identifier" 
    ON ("opera_prediction_molecule"."inchikey" = "chemical_identifier"."inchikey")
   LEFT OUTER JOIN "opera_aoh_endpoint"
    ON ("opera_prediction_molecule"."id" = "opera_aoh_endpoint"."molecule_id")
  LEFT OUTER JOIN "opera_bcf_endpoint"
    ON ("opera_prediction_molecule"."id" = "opera_bcf_endpoint"."molecule_id")
  LEFT OUTER JOIN "opera_biodeg_endpoint"
    ON ("opera_prediction_molecule"."id" = "opera_biodeg_endpoint"."molecule_id")
  LEFT OUTER JOIN "opera_bp_endpoint"
    ON ("opera_prediction_molecule"."id" = "opera_bp_endpoint"."molecule_id")
  LEFT OUTER JOIN "opera_caco2_endpoint"
    ON ("opera_prediction_molecule"."id" = "opera_caco2_endpoint"."molecule_id")
  LEFT OUTER JOIN "opera_clint_endpoint"
    ON ("opera_prediction_molecule"."id" = "opera_clint_endpoint"."molecule_id")
  LEFT OUTER JOIN "opera_fub_endpoint"
    ON ("opera_prediction_molecule"."id" = "opera_fub_endpoint"."molecule_id")
  LEFT OUTER JOIN "opera_hl_endpoint"
    ON ("opera_prediction_molecule"."id" = "opera_hl_endpoint"."molecule_id")
  LEFT OUTER JOIN "opera_km_endpoint"
    ON ("opera_prediction_molecule"."id" = "opera_km_endpoint"."molecule_id")
  LEFT OUTER JOIN "opera_koa_endpoint"
    ON ("opera_prediction_molecule"."id" = "opera_koa_endpoint"."molecule_id")
  LEFT OUTER JOIN "opera_koc_endpoint"
    ON ("opera_prediction_molecule"."id" = "opera_koc_endpoint"."molecule_id")
  LEFT OUTER JOIN "opera_logp_endpoint"
    ON ("opera_prediction_molecule"."id" = "opera_logp_endpoint"."molecule_id")
  LEFT OUTER JOIN "opera_mp_endpoint"
    ON ("opera_prediction_molecule"."id" = "opera_mp_endpoint"."molecule_id")
  LEFT OUTER JOIN "opera_vp_endpoint"
    ON ("opera_prediction_molecule"."id" = "opera_vp_endpoint"."molecule_id")
  LEFT OUTER JOIN "opera_ws_endpoint"
    ON ("opera_prediction_molecule"."id" = "opera_ws_endpoint"."molecule_id")
  LEFT OUTER JOIN "opera_rbiodeg_endpoint"
    ON ("opera_prediction_molecule"."id" = "opera_rbiodeg_endpoint"."molecule_id")
  LEFT OUTER JOIN "opera_rt_endpoint"
    ON ("opera_prediction_molecule"."id" = "opera_rt_endpoint"."molecule_id")
  LEFT OUTER JOIN "opera_logd_endpoint"
    ON ("opera_prediction_molecule"."id" = "opera_logd_endpoint"."molecule_id")
  LEFT OUTER JOIN "opera_pka_endpoint"
    ON ("opera_prediction_molecule"."id" = "opera_pka_endpoint"."molecule_id")
  LEFT OUTER JOIN "opera_catmos_endpoint"
    ON ("opera_prediction_molecule"."id" = "opera_catmos_endpoint"."molecule_id")
 WHERE "chemical_identifier"."cichem" = ANY(ARRAY[\'CICHEM000200014\', \'CICHEM000200048\']) AND 
    "opera_prediction_molecule"."opera_version" = ', opera.version, '
 ORDER BY "opera_prediction_molecule"."opera_version" DESC
 LIMIT 100
')


  # ── Call the stored procedure ─────────────────────────────────────────────────

  proc_sql <- sprintf(
    "SELECT * FROM get_padel_descriptors($1, $2, $3) AS t(%s)",
    col_defs
  )

  Padel <- dbGetQuery(con, proc_sql, params = list(
    paste0("{", paste(cichem_list, collapse = ","), "}"),
    opera_version,
    ifelse(is.null(column_names), 
        NA, 
        paste0("{", paste(column_names, collapse = ","), "}")
        )  # NA -> NULL in RPostgres
    )
    )

  return (Padel)
}